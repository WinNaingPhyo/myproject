-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 03, 2023 at 05:46 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `foodyfido`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `b_id` int(100) NOT NULL AUTO_INCREMENT,
  `b_title` text NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`b_id`, `b_title`) VALUES
(1, 'Hot Drink'),
(2, 'Cold Drink'),
(3, 'Spicy'),
(4, 'Sweet'),
(5, 'Snack');

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE IF NOT EXISTS `buy` (
  `brand` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `delivery` varchar(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `Order_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`brand`, `type`, `price`, `phone`, `delivery`, `address`, `Order_no`) VALUES
('Hot Drink', 'Candy Cane-Kahlua', '10000Ks', '09123456', 'next day', 'Ygn', 'no87'),
('Cold Drink', 'Tom Collins', '8000Ks', '09876543', '5 days', 'Mdy', 'no100'),
('Snack', 'Hostess Snoballs', '3000Ks', '1234123123', '3 days', 'Bago\r\n', 'no86'),
('Snack', 'Glazed Donut', '2000Ks', '121112122', '5 days', 'Nay Pyi Taw', 'no97'),
('Sweet', 'M&M Cookie Bars', '8000Ks', '09128472', 'next day', 'Ygn', 'no198');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `feedback` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`email`, `phone`, `feedback`) VALUES
('winwin@gmail.com', '09123456', 'make more options\r\n'),
('winwin@gmail.com', '0912838121', 'Hello'),
('winwin@gmail.com', '0912838121', 'Hi');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` varchar(20) NOT NULL,
  `p_brand` text NOT NULL,
  `p_type` varchar(50) NOT NULL,
  `p_price` varchar(100) NOT NULL,
  `p_image` text NOT NULL,
  `p_desc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `p_brand`, `p_type`, `p_price`, `p_image`, `p_desc`) VALUES
('1', 'Hot Drink', 'Boozy Apple Cider', '10000Ks', 'Boozy Apple Cider.jpg', 'Nice and smooth'),
('2', 'Hot Drink', 'Crockpot Red Wine', '15000Ks', 'Crockpot Red Wine Hot Cocoa.jpg', 'Smooth'),
('3', 'Hot Drink', 'Irish Coffee', '8000Ks', 'Irish Coffee.jpeg', 'Smell good'),
('4', 'Hot Drink', 'Peppermint Chocolate', '12000Ks', 'Peppermint Hot Chocolate.jpg', 'Sweet'),
('6', 'Hot Drink', 'Candy Cane-Kahlua', '10000Ks', 'Candy Cane-Kahlua Hot Chocolate.jpg', 'This is THE drink you''ll want to be sipping on Christmas morning. Take that, peppermint mocha.'),
('7', 'Cold Drink', 'Lemon or Lime Soda', '5000Ks', 'Lemon or Lime Soda.jpg', 'This is undoubtedly the easiest to make summer drink. You can indulge in an occasional lemon treat with a healthy version of soda made with freshly cut lemon or lime and a small amount of sugar additives'),
('8', 'Cold Drink', 'Mojito', '7000Ks', 'Mojito.jpg', 'This classic cocktail derives from Cuba and requires just five ingredients: white rum, sugar, lime juice, mint, and soda water.'),
('9', 'Cold Drink', 'Tom Collins', '8000Ks', 'Tom Collins.jpg', 'This classic cocktail has been popular for decades, and our version calls for just two ingredients: gin and lemon soda.'),
('10', 'Cold Drink', 'Espresso Slushy', '6000Ks', 'Espresso Slushy.jpg', 'Instant espresso gives a low-cal cool drink some kick.'),
('11', 'Cold Drink', 'Raspberry Fizz', '7500Ks', 'Raspberry Fizz.jpg', 'Top a ginger ale–cranberry juice combo with scoops of raspberry sorbet.'),
('12', 'Cold Drink', 'Raspberry Rum Cocktail', '12000Ks', 'Raspberry Rum Cocktail.jpg', 'To make this unique and flavorful cocktail, start with dark rum, then add pureed raspberries, fresh apple juice, lime, and a splash of ginger ale.'),
('5', 'Hot Drink', 'Hot Toddies', '10000Ks', 'Hot Toddies.jpg', 'Nice'),
('13', 'Spicy', 'Firecracker Chicken', '1300Ks', 'Firecracker Chicken.jpg', 'This firecracker chicken recipe is chunks of crispy chicken tossed in a sweet and spicy sauce. An easy dinner option that the whole family will love!'),
('14', 'Spicy', 'Spicy Dishes', '8000Ks', 'Spicy Dishes.jpg', 'Steak Salad With Cucumber, Peppers, and Spicy Fish Sauce Vinaigrette'),
('15', 'Spicy', 'Isan-Style Salad', '8000Ks', 'Isan-Style Thai Sliced-Steak Salad.jpg', 'That dressing gets tossed with sliced steak, tomatoes, onions, and fried lemongrass, for a complete summer meal.'),
('16', 'Spicy', 'Thai-Style Beef', '6000Ks', 'Thai-Style Beef With Basil and Chilies.jpg', ' A more accessible and no less delicious alternative is phat bai horapha, or stir-fried beef with basil (Thai purple or ordinary sweet basil is fine) and chilies'),
('17', 'Spicy', 'Isan-Style Spicy', '5000Ks', 'Isan-Style Spicy.jpg', 'Tomatoes, herbs, and bean sprouts balance out the rich chicharrones with freshness, and a spicy, sweet, acidic Thai-style dressing imparts big flavor.'),
('18', 'Spicy', 'Suanla Chaoshou', '12500Ks', 'Suanla Chaoshou.jpg', ' stuffed with pork, scallions, and garlic swim happily in a sauce of chilies, peppercorns, and sweet Chinkiang vinegar in this flavor-packed dish.'),
('19', 'Sweet', 'Skillet Texas Sheet Cake', '4500Ks', 'Skillet Texas Sheet Cake.jpg', ' Using a skillet eliminates a dish and makes things way more fun. Especially when everyone digs in while it''s still warm... with tons of ice cream on top.'),
('20', 'Sweet', 'Cheesecake Egg Rolls', '7000Ks', 'Cheesecake.jpg', 'Crazy egg rolls are kind of our thing and we love this cheesecake version. The strawberry jam-esque dipping sauce isn''t mandatory, but trust us, it''s SO good.'),
('21', 'Sweet', 'M&M Cookie Bars', '8000Ks', 'M&M Cookie Bars.jpg', 'These have all the comfort of a chocolate chip cookie, with the added crunch of M&M''s and the heft of a bar shape, making for a delicious treat that’s impossible to put down'),
('22', 'Sweet', 'Cookie Crack', '6000Ks', 'Cookie Crack.jpeg', 'The salty ''n'' sweet combo of pretzels, potato chips, and chocolate chip cookies is totally irresistible. '),
('23', 'Sweet', 'Funfetti Dip', '7000Ks', 'Funfetti Dip.jpg', 'It’s time to channel your inner big kid. This Funfetti dip is a fluffy mixture of butter, cream cheese, and powdered sugar, with nostalgic flavor coming from imitation vanilla extract and a little crunch from confetti sprinkles.'),
('24', 'Snack', 'Glazed Donut', '2000Ks', 'donut.jpg', '4 PIECES: 240 calories, 14g fat (6g saturated fat), 150mg sodium, 28g carbs (<1g fiber, 18g sugar), 2g protein'),
('25', 'Snack', 'Hostess Snoballs', '3000Ks', 'Hostess Snoballs.jpg', '1 CAKE: 160 calories, 5g fat (3g saturated fat), 180mg sodium, 29g carbs (1g fiber, 20g sugar), 1g protein'),
('26', 'Snack', 'Oreos', '1000Ks', 'Oreos.jpg', '3 COOKIES: 160 calories, 7g fat (2g saturated fat), 135mg sodium, 25g carbs (<1g fiber, 14g sugar), 1g protein'),
('27', 'Snack', 'Chocolate Peppermint', '1000Ks', 'Chocolate Peppermint.jpg', '1 CANDY: 150 calories, 2.5g fat (1.5g saturated fat), 10mg sodium, 32g carbs (<1g fiber, 26g sugar), <1g protein');

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE IF NOT EXISTS `sign_up` (
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `gender` text NOT NULL,
  `birthday` varchar(20) NOT NULL,
  `country` text NOT NULL,
  `city` text NOT NULL,
  `township` text NOT NULL,
  `email_noti` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`first_name`, `last_name`, `email`, `password`, `phone_no`, `gender`, `birthday`, `country`, `city`, `township`, `email_noti`) VALUES
('WIN', 'WIN', 'winwin@gmail.com', 'win123', '098716125', 'male', '1/1/1900', 'Yangon', 'Yangon', 'Hlaing', 'yes'),
('Aung', 'Aung', 'aungaung@gmail.com', 'aung123', '0987654312', 'male', '1/1/1900', 'Myanmar', 'Yangon', 'Hlaing', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` text NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `password`) VALUES
('admin', 'user123');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
